import Adults from './pages/Adults';

export default function App() {
  return <Adults />;
}
